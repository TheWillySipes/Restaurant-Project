﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WindowsFormsApplication12
{
    public partial class MainMenu : Form 
    {
        public MainMenu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You are now clocked in");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You are now clocked out");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Ticket newTicket = new Ticket();

            newTicket.Show(); 
        }
    }
}
