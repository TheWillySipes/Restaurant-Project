﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication12
{
    public class Waiter
    {
        public Waiter()
        {
            throw new System.NotImplementedException();
        }
        //WAITER NAME , NAME CAN BE USED TO ACCESS THE INTERFACE 
      

        public void seatTable()
        {
            throw new System.NotImplementedException();
        }

        public void takeOrder()
        {
            throw new System.NotImplementedException();
        }
    }
}