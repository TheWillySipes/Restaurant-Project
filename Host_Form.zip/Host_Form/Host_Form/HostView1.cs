﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Host_Form
{
    public partial class HostView1 : Form
    {
        public HostView1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            int num = 0;
            string lBox = "";
            lBox = textBox1.ToString();
            if (int.TryParse(lBox, out num))
            {
                if(num > 0)
                {
                    
                }
            }
            else
            {
                string boxMessage = "The following entered is not a vaild number. Try again?";
                string caption = "Try again";
                var retry = MessageBox.Show(boxMessage, caption,MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if(retry == DialogResult.No)
                {
                    
                }
            }
        }
    }
}
