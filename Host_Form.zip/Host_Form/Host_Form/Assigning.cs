﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Host_Form
{
    public partial class Assigning : Form
    {
        public Assigning()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                //new HostView().Show();
            }
            else if (Occupied.Checked == true)
            {
                MessageBox.Show("This Table is Occupied!");
            }
            else if(radioButton3.Checked == true)
            {
                MessageBox.Show("This table is Drity!");   
            }
        }
    }
}
