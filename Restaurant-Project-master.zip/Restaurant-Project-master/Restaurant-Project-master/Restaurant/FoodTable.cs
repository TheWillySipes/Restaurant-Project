﻿using BusinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Restaurant
{
    class FoodTable
    {
        //Primary Key in Database
        public int FoodTableId { get; set; }
        //Table Status (Enum)
        public TableStatus TableStatus { get; set; }

        /// <summary>
        /// Set ticket Status
        /// </summary>
        /// <param name="status"></param>

        public Ticket Ticket { get; set; }

        /// <summary>
        /// Set Table Status
        /// </summary>
        /// <param name="status"></param>
        public void AssignTable(TableStatus status)
        {
            TableStatus = status;
        }

        //Get table status
        public TableStatus GetTableStatus()
        {
            if (TableStatus == TableStatus.Open)
            {
                MessageBox.Show("Table is available");
            }
            else if (TableStatus == TableStatus.Occupied)
            {
                MessageBox.Show("Table is occupied");
            }
            else if (TableStatus == TableStatus.Dirty)
            {
                MessageBox.Show("Table is dirty");
            }
            return TableStatus;
        }

        //Get Ticket status
        public void TicketStatus(Ticket status)
        {
            Ticket = status;
        }

        public Ticket GetTicketStatus()
        {
            if (Ticket == Ticket.TicketOpen)
            {
                MessageBox.Show("The ticket is open");
            }
            else if (Ticket == Ticket.TicketClose)
            {
                MessageBox.Show("The ticket is closed");
            }
           else
            {
                MessageBox.Show("Ticket does not exist, please create a new ticket. Thank you!");

            }
            return Ticket;
        }
    }
}
